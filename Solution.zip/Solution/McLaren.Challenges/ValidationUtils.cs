﻿using System;

using McLaren.Challenges.Resources;

namespace McLaren.Challenges
{
    internal static class ValidationUtils
    {
        public static void ValidateNotNull(string paramName, object paramValue)
        {
            if (paramValue == null)
                throw new ArgumentNullException(paramName, ExceptionMessages.ArgumentNull);
        }

        public static void ValidateNotNegative(string paramName, int paramValue)
        {
            if (paramValue < 0)
                throw new ArgumentOutOfRangeException(paramName, paramValue, ExceptionMessages.ArgumentOutOfRangeNegative);
        }
    }
}
