﻿namespace McLaren.Challenges.Algorithms
{
    /// <summary>
    /// Storage for information of palindromes found in a string.
    /// </summary>
    public sealed class PalindromMatch
    {
        internal PalindromMatch(string text, int index)
        {
            this.Text = text;
            this.Index = index;
        }

        public string Text { get; }
        public int Index { get; internal set; }
    }
}
