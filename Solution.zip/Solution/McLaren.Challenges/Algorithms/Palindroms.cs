﻿using System;
using System.Collections.Generic;

namespace McLaren.Challenges.Algorithms
{
    /// <summary>
    /// Supports palindrome string operations.
    /// </summary>
    public static class Palindroms
    {
        private const int DefaultFindMaxCount = 3;
        private const bool DefaultFindIgnoreCase = false;
        private const bool DefaultFindUnique = true;

        /// <summary>
        /// Finds the 3 longest unique palindromes in a supplied string performing a case-sensitive search.
        /// </summary>
        /// <param name="input">The supplied string in which to search for palindromes.</param>
        /// <returns>The list of information about found palindromes.</returns>
        /// <exception cref="System.ArgumentNullException">Thrown when <paramref name="input"/> is null.</exception>
        /// <remarks>
        /// The function is based on the Manacher's algorithm. In terms of time complexity it is a O(n) operation.
        /// </remarks>
        public static List<PalindromMatch> Find(string input)
        {
            return Find(input, DefaultFindMaxCount);
        }

        /// <summary>
        /// Finds the longest unique palindromes in a supplied string performing a case-sensitive search.
        /// </summary>
        /// <param name="input">The supplied string in which to search for palindromes.</param>
        /// <param name="maxCount">The maximum number of palindromes to return or 0 to indicate that all will be returned.</param>
        /// <returns>The list of information about found palindromes.</returns>
        /// <exception cref="System.ArgumentNullException">Thrown when <paramref name="input"/> is null.</exception>
        /// <exception cref="System.ArgumentOutOfRangeException">Thrown when <paramref name="maxCount"/> is less than zero.</exception>
        /// <remarks>
        /// The function is based on the Manacher's algorithm. In terms of time complexity it is a O(n) operation.
        /// </remarks>
        public static List<PalindromMatch> Find(string input, int maxCount)
        {
            return Find(input, maxCount, DefaultFindIgnoreCase, DefaultFindUnique);
        }

        /// <summary>
        /// Finds the longest unique palindromes in a supplied string, using a parameter to indicate whether to ignore case.
        /// </summary>
        /// <param name="input">The supplied string in which to search for palindromes.</param>
        /// <param name="maxCount">The maximum number of palindromes to return or 0 to indicate that all will be returned.</param>
        /// <param name="ignoreCase">Whether the character case is ignored or not.</param>
        /// <returns>The list of information about found palindromes.</returns>
        /// <exception cref="System.ArgumentNullException">Thrown when <paramref name="input"/> is null.</exception>
        /// <exception cref="System.ArgumentOutOfRangeException">Thrown when <paramref name="maxCount"/> is less than zero.</exception>
        /// <remarks>
        /// The function is based on the Manacher's algorithm. In terms of time complexity it is a O(n) operation.
        /// </remarks>
        public static List<PalindromMatch> Find(string input, int maxCount, bool ignoreCase)
        {
            return Find(input, maxCount, ignoreCase, DefaultFindUnique);
        }

        /// <summary>
        /// Finds the longest palindromes in a supplied string, using parameters to indicate whether to ignore case and to return unique matches.
        /// </summary>
        /// <param name="input">The supplied string in which to search for palindromes.</param>
        /// <param name="maxCount">The maximum number of palindromes to return or 0 to indicate that all will be returned.</param>
        /// <param name="ignoreCase">Whether the character case is ignored or not.</param>
        /// <param name="unique">Whether in case of repeated palindromes only the first occurance will be returned or not.</param>
        /// <returns>The list of information about found palindromes.</returns>
        /// <exception cref="System.ArgumentNullException">Thrown when <paramref name="input"/> is null.</exception>
        /// <exception cref="System.ArgumentOutOfRangeException">Thrown when <paramref name="maxCount"/> is less than zero.</exception>
        /// <remarks>
        /// The function is based on the Manacher's algorithm. In terms of time complexity it is a O(n) operation.
        /// </remarks>
        public static List<PalindromMatch> Find(string input, int maxCount, bool ignoreCase, bool unique)
        {
            ValidationUtils.ValidateNotNull("input", input);
            ValidationUtils.ValidateNotNegative("maxCount", maxCount);

            // If there's nothing to do, take the short way out.
            if (input.Length <= 1)
                return new List<PalindromMatch>();

            // Create a character comparer before the loop so we don't have to check in each iteration if case sensitivity is requested.
            // A lowercase copy of the original string could be used instead but it wouldn't be good in terms of memory for huge strings.
            Func<char, char, bool> charsAreEqual;

            if (ignoreCase)
                charsAreEqual = (a, b) => char.ToLower(a) == char.ToLower(b);
            else
                charsAreEqual = (a, b) => a == b;

            // A palindrome can either have an odd length and a character at its center or an even length and its center between two characters.
            // To cover both cases in a single process we add additional characters at the start, end and between each character.
            // Thus, all palindromes of the original string are converted to odd lengthed palindromes.
            char[] extendedInput = AddSeparators(input.ToCharArray());

            int[] palSpans = new int[extendedInput.Length]; // Distances from palindrome centers to their boundaries.

            int palCenterIndex = 0, palRightIndex = 0; // Information of palindrome currently known to include a boundary closest to the right edge.
            int leftRunner = 0, rightRunner = 0;       // Mirroring indices to compare if two characters are equal.

            // Information storage about found palindromes.
            List<int> palIndices = new List<int>();
            List<int> palLengths = new List<int>();

            for (int i = 1; i < extendedInput.Length - 1; i++) // We exclude first and last characters as they can't be centers of palindromes.
            {
                if (i > palRightIndex) // We don't know the span. Initialize runners for comparison of left and right sides from the current position.
                {
                    leftRunner = i - 1;
                    rightRunner = i + 1;
                }
                else // We are inside a palindrome. Check if we already know the span from the mirrored position.
                {
                    int mirrorIndex = 2 * palCenterIndex - i;

                    if (palSpans[mirrorIndex] < palRightIndex - i - 1) // We know the span.
                    {
                        palSpans[i] = palSpans[mirrorIndex];
                        leftRunner = -1; // To bypass the loop below.
                    }
                    else // We are inside another palindrome that exceeds the known one. Initialize runners to start from the nearer unexplored position.
                    {
                        palSpans[i] = palRightIndex - i;
                        rightRunner = palRightIndex + 1;
                        leftRunner = 2 * i - rightRunner;
                    }
                }
                
                while (leftRunner >= 0 && rightRunner < extendedInput.Length && charsAreEqual(extendedInput[leftRunner], extendedInput[rightRunner]))
                {
                    palSpans[i]++;
                    leftRunner--;
                    rightRunner++;
                }

                //Check for boundary closest to the right edge.
                int nextPalRightIndex = i + palSpans[i];

                if (nextPalRightIndex > palRightIndex)
                {
                    palCenterIndex = i;
                    palRightIndex = nextPalRightIndex;
                }

                // Store palindrome information.
                // Due to the addition of separator characters we ignore spans of value 1 as they respond to a single character in the original string.
                if (palSpans[i] >= 2)
                {
                    palIndices.Add((i - palSpans[i]) / 2);
                    palLengths.Add(palSpans[i]);
                }
            }
            
            return CreateMatches(input, palIndices.ToArray(), palLengths.ToArray(), maxCount, ignoreCase, unique);
        }

        private static char[] AddSeparators(char[] input)
        {
            const char Separator = '|';

            char[] output = new char[2 * input.Length + 1];

            for (int i = 0; i < input.Length; i++)
            {
                output[2 * i] = Separator;
                output[2 * i + 1] = input[i];
            }

            output[output.Length - 1] = Separator;
            return output;
        }

        private static List<PalindromMatch> CreateMatches(string input, int[] palIndices, int[] palLengths, int maxCount, bool ignoreCase, bool unique)
        {
            List<PalindromMatch> matches = new List<PalindromMatch>();

            // A dictionary is needed to check for uniqueness.
            StringComparer comparer = ignoreCase ? StringComparer.OrdinalIgnoreCase : StringComparer.Ordinal;
            Dictionary<string, PalindromMatch> matchesByText = new Dictionary<string, PalindromMatch>(comparer);
            
            Array.Sort(palLengths, palIndices);

            for (int i = palIndices.Length - 1; i >= 0; i--)
            {
                string matchText = input.Substring(palIndices[i], palLengths[i]);
                PalindromMatch match = new PalindromMatch(matchText, palIndices[i]);

                if (unique)
                {
                    PalindromMatch duplicateMatch;

                    // If a duplicate match is found we set the index to the smaller one.
                    if (matchesByText.TryGetValue(matchText, out duplicateMatch))
                    {
                        if (duplicateMatch.Index > match.Index)
                            duplicateMatch.Index = match.Index;

                        continue;
                    }
                    else
                    {
                        matchesByText.Add(matchText, match);
                    }
                }

                matches.Add(match);

                if (maxCount > 0 && matches.Count == maxCount)
                    break;
            }

            return matches;
        }
    }
}
