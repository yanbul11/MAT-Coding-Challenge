﻿using System.Web.Http;

using McLaren.Challenges.Algorithms;

namespace McLaren.Web.ChallengeDemo.Areas.Algorithms.Controllers
{
    public class PalindromesController : ApiController
    {
        [HttpPost]
        public IHttpActionResult Find([FromBody]string input)
        {
            if (string.IsNullOrEmpty(input))
                return BadRequest(Resources.Content.PalindromesInputEmpty);

            return Ok(Palindroms.Find(input));
        }
    }
}
