﻿using System.Web.Http;
using System.Web.Mvc;

namespace McLaren.Web.ChallengeDemo.Areas.Algorithms
{
    public class AlgorithmsAreaRegistration : AreaRegistration 
    {
        public override string AreaName 
        {
            get 
            {
                return "Algorithms";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context) 
        {
            context.Routes.MapHttpRoute(
                name: "AlgorithmsApi",
                routeTemplate: "api/algorithms/{controller}/{action}"
            );
        }
    }
}