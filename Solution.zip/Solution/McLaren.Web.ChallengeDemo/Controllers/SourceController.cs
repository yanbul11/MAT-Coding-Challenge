﻿using System.Web.Mvc;

namespace McLaren.Web.ChallengeDemo.Controllers
{
    public class SourceController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}