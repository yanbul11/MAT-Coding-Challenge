﻿using System.Web.Mvc;

namespace McLaren.Web.ChallengeDemo.Controllers
{
    public class NotesController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}